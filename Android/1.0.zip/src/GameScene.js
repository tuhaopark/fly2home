FP_MAIN_TEXTURE = {
    FRAME_ANIMS: "beanstalk/Resources/bs_main_anims.plist",
    IRON: ["holdback1.png", "holdback2.png"]
}
READY = 1;
START = 2;
OVER = 3;

//================================================
//================================================
var GameScene = function(){
    cc.log("GetReadyLayer");
    this.bird = this.bird || {};
    this.ground_dn = this.ground_dn || {};
    this.ground_up = this.ground_dn || {};
    this.getready = this.getready || {};
    this.finger = this.finger || {};
    this.clicknode = this.clicknode || {};
    this.gameover = this.gameover || {};
    this.ironNode = this.ironNode || {};
    this.ironSpriteList = [];
    this.passTime = 0;
    this.isStart = false;
    this.gameMode = READY;
};

//================================================
//================================================
GameScene.prototype.onDidLoadFromCCB = function () {
    cc.log("Did Load CCB");
    if (sys.platform == 'browser') {
        this.onEnter();
    }
    else {
        this.rootNode.onEnter = function () {
            this.controller.onEnter();
        };
    }

    this.rootNode.schedule(function (dt) {
        this.controller.onUpdate(dt);
    });

    this.rootNode.onExit = function () {
        this.controller.onExit();
    };

    this.rootNode.onTouchesBegan = function (touches, event) {
        this.controller.onTouchesBegan(touches, event);
        return true;
    };

    this.rootNode.onTouchesMoved = function (touches, event) {
        this.controller.onTouchesMoved(touches, event);
        return true;
    };
    this.rootNode.onTouchesEnded = function (touches, event) {
        this.controller.onTouchesEnded(touches, event);
        return true;
    };
    this.rootNode.setTouchEnabled(true);
};
//================================================
//================================================
GameScene.prototype.onBack = function()
{
    this.rootNode.unscheduleAllCallbacks();
    cc.Director.getInstance().replaceScene(CCBStartScene());

}

//================================================
//================================================
GameScene.prototype.onEnter = function () {
    cc.AnimationCache.getInstance().addAnimations("ccbResources/bird_frame.plist");
    cc.AnimationCache.getInstance().addAnimations("ccbResources/finger_frame.plist");
    this.groundRun();
    this.ground_dn.setZOrder(10);
    this.ground_up.setZOrder(10);
    this.birdReadyAction();
    this.bird.setZOrder(20);
    this.gameover.setVisible(false);
    for (var i = 0; i < 30; i++) {
        this.newIron(i);
    }
};

//================================================
//Make random Iron Stand
//================================================
GameScene.prototype.newIron = function (num) {
    var winsize =  cc.Director.getInstance().getWinSize();
//    cc.log("W:"+winsize.width+" h:"+winsize.height);
//    this.ironNode.setPositionY(winsize.height/2);

    var ironHeight = 720;
    var acrossHeight = 300;
    var downHeight = 120+getRandom(400);
    var upHeight = downHeight + acrossHeight;


    var ironX = 400 * num;
    var IronName = FP_MAIN_TEXTURE.IRON;
    var ccSpriteUp = cc.Sprite.createWithSpriteFrameName(IronName[1]);
//    var ccSpriteUp = cc.Sprite.create(IronName[1]);
    ccSpriteUp.setZOrder(1);
    ccSpriteUp.setAnchorPoint(cc.p(0, 0));
    ccSpriteUp.setPosition(cc.p(ironX, upHeight));

    var ccSpriteDown = cc.Sprite.createWithSpriteFrameName(IronName[0]);
//    var ccSpriteDown = cc.Sprite.create(IronName[0]);
    ccSpriteDown.setZOrder(1);
    ccSpriteDown.setAnchorPoint(cc.p(0, 1));
    ccSpriteDown.setPosition(cc.p(ironX, downHeight));


    this.ironNode.addChild(ccSpriteDown);
    this.ironNode.addChild(ccSpriteUp);
    this.ironSpriteList.push(ccSpriteDown);
    this.ironSpriteList.push(ccSpriteUp);

    return null;
}

//================================================
//Bird Fly Animation
//================================================
GameScene.prototype.birdReadyAction = function () {
    var birdX = this.bird.getPositionX();
    var birdY = this.bird.getPositionY();
    var time = birdY / 2000;
    var actionFrame = cc.Animate.create(cc.AnimationCache.getInstance().getAnimation("fly"));
    this.bird.runAction(cc.RepeatForever.create(actionFrame));

    var ClickX = this.finger.getPositionX();
    var ClickY = this.finger.getPositionY();
    var actionFingerFrame = cc.Animate.create(cc.AnimationCache.getInstance().getAnimation("click"));
    this.finger.runAction(cc.RepeatForever.create(actionFingerFrame));
};

//================================================
//Bird Rise(up) AND down
//================================================
GameScene.prototype.birdRiseAction = function () {
    var riseHeight = 60;
    var birdX = this.bird.getPositionX();
    var birdY = this.bird.getPositionY();
    var time = birdY / 600;

    var actionFrame = cc.Animate.create(cc.AnimationCache.getInstance().getAnimation("fly"));
    var flyAction = cc.Repeat.create(actionFrame, 90000);
    var riseAction1 = cc.MoveTo.create(0.2, cc.p(birdX, birdY + riseHeight));
    var riseAction2 = cc.RotateTo.create(0, -30);
    var riseAction = cc.Spawn.create(riseAction1, riseAction2);
    var fallAction1 = cc.MoveTo.create(time, cc.p(birdX, 50));
    var fallAction2 = cc.Sequence.create(cc.DelayTime.create(time / 6), cc.RotateTo.create(0, 30));
    var fallAction = cc.Spawn.create(fallAction1, fallAction2);

    this.bird.stopAllActions();
    this.bird.runAction(cc.Spawn.create(
        cc.Sequence.create(riseAction, cc.DelayTime.create(0.1), fallAction),
        flyAction)
    );
};
//================================================
//Bird Fall Down
//================================================
GameScene.prototype.birdFallAction = function () {
    this.gameMode = OVER;
    this.bird.stopAllActions();
    this.ground_dn.stopAllActions();
    this.ground_up.stopAllActions();
    var birdX = this.bird.getPositionX();
    var birdY = this.bird.getPositionY();
    var time = birdY / 2000;
    this.bird.runAction(cc.Sequence.create(
        cc.DelayTime.create(0.1),
        cc.Spawn.create(cc.RotateTo.create(time, 90), cc.MoveTo.create(time, cc.p(birdX, 50))))
    );
    this.gameover.setVisible(true);
    getads();
    cc.log("get ADs");

};
//================================================
//================================================
GameScene.prototype.checkCollision = function () {
    if (this.bird.getPositionY() < 60) {
        cc.log("floor");
        this.birdFallAction();
        return;
    }
    for (var i = 0; i < this.ironSpriteList.length; i++) {
        var iron = this.ironSpriteList[i];
        if (!this.isInScreen(iron)) {
            // continue;
        }

        if (cc.rectIntersectsRect(iron.getBoundingBox(), this.bird.getBoundingBox())) {
            cc.log("iron positionX==" + iron.getBoundingBox().x);
            cc.log("this.bird positionX==" + this.bird.getBoundingBox().x);
            cc.log("i==" + i);
            cc.log("birdFallAction");
            this.birdFallAction();
            return;
        }
    }
};

//================================================
//================================================
GameScene.prototype.onUpdate = function (dt) {
    if (this.gameMode != START) {
        return;
    }
    this.passTime += dt;
    this.ironNode.setPositionX(800 - 200 * this.passTime);
    this.bird.setPositionX(-650 + 200 * this.passTime);
    this.checkCollision();
};



//================================================
// Ground Move
//================================================
GameScene.prototype.groundRun = function () {
    var action1 = cc.MoveTo.create(0.5, cc.p(-80, 0));
    var action2 = cc.MoveTo.create(0, cc.p(0, 0));
    var action = cc.Sequence.create(action1, action2);
    this.ground_dn.runAction(cc.RepeatForever.create(action));
    var action1_up = cc.MoveTo.create(0.5, cc.p(-80, 960));
    var action2_up = cc.MoveTo.create(0, cc.p(0, 960));
    var action_up = cc.Sequence.create(action1_up, action2_up);
    this.ground_up.runAction(cc.RepeatForever.create(action_up));
};


GameScene.prototype.isInScreen = function (sprite) {
    return (sprite.getPositionX() > 0 && sprite.getPositionX() < 720);
};

//================================================
//================================================
GameScene.prototype.onExitClicked = function () {
};

//GameScene.prototype.onStartClicked = function () {
//    cc.Director.getInstance().resume();
//    cc.BuilderReader.runScene("", "MainLayer");
//}

//================================================
//================================================
GameScene.prototype.onExit = function () {
    cc.log("onExit");
};

//================================================
//================================================
GameScene.prototype.onTouchesBegan = function (touches, event) {
    var loc = touches[0].getLocation();
};

//================================================
//================================================
GameScene.prototype.onTouchesMoved = function (touches, event) {
};

//================================================
//================================================
GameScene.prototype.onTouchesEnded = function (touches, event) {
    if (this.gameMode == OVER) {
        return;
    }

    if (this.gameMode == READY) {
        this.gameMode = START;
        this.getready.setVisible(false);
        this.clicknode.setVisible(false);
        this.finger.setVisible(false);
    }

    var loc = touches[0].getLocation();
    this.birdRiseAction();

};


//================================================
//================================================
function isInRect(ccRect, ccTouchBeganPos) {
    if (ccTouchBeganPos.x > ccRect.x && ccTouchBeganPos.x < (ccRect.x + ccRect.width)) {
        if (ccTouchBeganPos.y > ccRect.y && ccTouchBeganPos.y < (ccRect.y + ccRect.height)) {
            return true;
        }
    }
    return false;
}

//================================================
//================================================
function getRandom(maxSize) {
    return Math.floor(Math.random() * maxSize) % maxSize;
};

//================================================
//
//================================================
var CCBGameScene = function () {
    cc.log("CCBGameScene");
    var scene = cc.Scene.create();
//    cc.BuilderReader.setResolutionScale(1);
    node = cc.BuilderReader.load("GameScene.ccbi");

    scene.addChild(node);
    scene.setPosition(cc.p(0, 0));

    return scene;
};