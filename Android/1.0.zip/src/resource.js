

var g_ressources = [
    {type:'ccbi', src:"Welcome.ccbi"},
    {type:'ccbi', src:"StartScene.ccbi"},
    {type:'ccbi', src:"GameScene.ccbi"},


    {type:'plist', src:"ccbResources/bird_frame.plist"},
    {type:'plist', src:"ccbResources/finger_frame.plist"},
    {type:'plist', src:"ccbResources/birdfly.plist"},

    {type:'image', src:"ccbResources/bg_1.png"},
    {type:'image', src:"ccbResources/bg_1136.png"},
    {type:'image', src:"ccbResources/birdfly.png"},

    {type:'image', src:"ccbResources/number_2.png"},
    {type:'image', src:"ccbResources/number_1.png"},
    {type:'image', src:"ccbResources/welcome.png"}
];