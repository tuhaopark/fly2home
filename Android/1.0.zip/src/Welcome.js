//
// MainScene class
//
var Welcome = function(){
    this.passTime = 0;
};

Welcome.prototype.onDidLoadFromCCB = function () {
    cc.log("Welcome onDidLoadFromCCB");

    this.rootNode.schedule(function (dt) {
        this.controller.onUpdate(dt);
    });
};

//================================================
//================================================
//Welcome.prototype.onCallback1 = function(sender) {
//    cc.log("CallBack1");
//}
//================================================
//================================================
Welcome.prototype.onUpdate = function (dt) {
    this.passTime += dt;

    if (this.passTime > 3)
    {
        this.rootNode.unscheduleAllCallbacks();
        cc.Director.getInstance().replaceScene(CCBStartScene());
    }
};


// Create callback for button
//MainScene.prototype.onPressButton = function()
//{
//    cc.Director.getInstance().replaceScene(CCBGameScene());
//};

var CCBWelcome = cc.Scene.extend({
    ctor:function () {
        this._super();
        cc.associateWithNative( this, cc.Scene );
        cc.BuilderReader.setResolutionScale(1);
        var node = cc.BuilderReader.load("Welcome.ccbi");

        if(node != null) {
            this.addChild(node);
            this.setPosition(cc.p(0, 0));
        }

    }
});