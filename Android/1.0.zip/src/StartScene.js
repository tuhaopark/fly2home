//
// StartScene class
//
var StartScene = function(){
    cc.log("Start Scene");
};
StartScene.prototype.onDidLoadFromCCB = function () {
    cc.log("StartcScene onDidLoadFromCCB");
//    this.titleRun();
};


// Create callback for button
StartScene.prototype.onPressButton = function()
{
    cc.Director.getInstance().replaceScene(CCBGameScene());
};

var CCBStartScene = function () {
    cc.log("CCBStartScene");
    var scene = cc.Scene.create();
//    cc.BuilderReader.setResolutionScale(1);
    node = cc.BuilderReader.load("StartScene.ccbi");

    scene.addChild(node);
    scene.setPosition(cc.p(0, 0));

    return scene;
};