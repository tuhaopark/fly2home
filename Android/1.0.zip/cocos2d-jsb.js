
// boot code needed for cocos2d + JS bindings.
// Not needed by cocos2d-html5

require("jsb.js");

var appFiles = [
    'src/Welcome.js',
    'src/StartScene.js',
    'src/GameScene.js',
    'src/resource.js'
];

cc.dumpConfig();

for( var i=0; i < appFiles.length; i++) {
    require( appFiles[i] );
}

cc.FileUtils.getInstance().loadFilenameLookup("fileLookup.plist");
var director = cc.Director.getInstance();
director.setDisplayStats(false);

// set FPS. the default value is 1.0/60 if you don't call this
director.setAnimationInterval(1.0 / 60);

// create a scene. it's an autorelease object

var scene = cc.BuilderReader.loadAsScene("Welcome");

var runningScene = director.getRunningScene();
if (runningScene === null) director.runWithScene(scene);
else director.replaceScene(scene);

//var myScene = new MyScene();
// run
//director.runWithScene(myScene);

